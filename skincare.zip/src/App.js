import "./index.css";
import Header from "./skincare/header";
import Footer from "./skincare/footer";
import Home from "./skincare/home";

function App() {
  return (
    <div>
      <Header />
      <Home />
      <Footer />
    </div>
  );
}

export default App;
