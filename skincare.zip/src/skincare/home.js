const Home = () => {
  return (
    <>
      <div className="bg-[#EFF5E1] pb-[15px] relative">
        <div className="w-[90%] pt-[8%] pb-[6%] mx-auto flex items-center justify-between">
          <div className="w-[24.5%]">
            <p className="font-inter font-normal text-[20px] leading-[25px] indent-[101px] text-[#2D3B36]">
              Transform your skincare routine with premium products that
              restore, protect, and enhance your natural glow every day.
            </p>
          </div>
          <div className="w-[30%]">
            <p className="font-inter font-bold text-[100px] leading-[90px] uppercase text-[#2D3B36]">
              Glow Natur-ally
            </p>
          </div>
          <div className="w-fit">
            <img
              src="/images/section1.jpg"
              alt="skincare"
              className="w-[222.61px] h-[220px] rounded-[20px]"
            />
          </div>
        </div>
        <div className="flex items-center mx-auto w-[90%]">
          <div className="bg-[#2D3B36] w-[180px] h-[60px] rounded-[100px] flex justify-center items-center">
            <p className="font-inter font-normal text-[20px] leading-[25px] text-[#EFF5E1] capitalize">
              shop now
            </p>
          </div>

          <div className="w-fit mx-auto relative z-10">
            <img
              src="/images/section2.jpg"
              alt="skincare"
              className="w-[610px] h-[676px] rounded-[30px]"
            />
            <div className="absolute bottom-[5%] right-0 left-0 mx-auto w-[476px] h-[100px] flex items-center justify-between bg-[#EFF5E1] rounded-[200px] py-[20px] px-[5px]">
              <div className="w-[88px] h-[88px] rounded-full flex justify-center items-center border border-dotted border-[#2D3B36]">
                <img
                  src="/images/section1.jpg"
                  alt="skincare"
                  className="w-[80px] h-[80px] rounded-full object-cover"
                />
              </div>
              <div className="w-[75%]">
                <p className="font-inter font-normal text-[20px] leading-[25px] text-[#2D3B36] capitalize">
                  While giving you an invigorating cleansing experience.
                </p>
              </div>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0">
          <h1 className="text-[clamp(80px,19.26vw,378px)] font-inter font-extrabold leading-[73%] uppercase text-[#2D3B36]">
            skincare
          </h1>
        </div>
      </div>
      <div className="bg-[#FEFFF4] pt-[6%]">
        <div className="w-[90%] mx-auto pb-[12%]">
          <p className="font-inter font-normal text-[clamp(20px,2.75vw,53px)] leading-[78px] tracking-[-0.035em] text-[#2D3B36]">
            Experience the ultimate in skincare with our expertly formulated
            products, crafted to nourish, protect, and rejuvenate your skin.
            Combining the finest natural ingredients with
            <span className="text-[#2D3B36]/30">
              {" "}
              advanced science, our collection ensures every skin type can
              achieve a radiant, healthy glow. Embrace your beauty with
              confidence every day. Experience the ultimate in skincare with our
              expertly formulated products, crafted to nourish, protect, and
              rejuvenate your skin.
            </span>
          </p>
        </div>
        <div className="flex justify-between w-[90%] mx-auto pb-[12%]">
          <div className="w-[50%] flex flex-col gap-[40px]">
            <div className="w-fit flex items-center gap-[20px] bg-[#FEFFF4] rounded-[100px] px-[20px] py-[10px] border border-[#2D3B36]">
              <div className="w-[20px] h-[20px] rounded-full bg-[#2D3B36]"></div>
              <p className="font-inter font-normal text-[20px] leading-[25px] text-[#2D3B36] capitalize">
                Why Our Products
              </p>
            </div>

            <p className="font-inter font-normal text-[clamp(40px,4vw,60px)] tracking-[-0.02em] leading-[100%] text-[#2D3B36]">
              YOUR SKIN DESERVES THE BEST CARE.
            </p>
            <p className="font-inter font-normal text-[18px] leading-[24px] text-[#525349] w-[90%]">
              Discover a curated collection of skincare products designed to
              rejuvenate, protect, and pamper your skin. Explore our range
              crafted with love backed by science, and inspired by nature.
            </p>

            <div className="flex flex-col gap-[55px]">
              <div className="flex gap-[20px]">
                <div className="w-[11%]">
                  <p className=" bg-gradient-to-b from-[#293330] to-[#FEFFF4] bg-clip-text text-transparent text-[60px] font-inter font-normal leading-[60px] text-[#2D3B36]">
                    01
                  </p>
                </div>
                <div className="flex flex-col gap-[20px] w-[89%]">
                  <h3 className="text-[60px] font-inter font-normal leading-[60px] text-[#2D3B36]">
                    Bio Ingredients
                  </h3>
                  <p className="text-[18px] font-normal font-inter text-[#525349] w-[70%]">
                    Get naturally beautiful and transform with our bio
                    ingredients creams for healthy, radiant skin.
                  </p>
                </div>
              </div>
              <div className="flex gap-[20px]">
                <div className="w-[11%]">
                  <p className=" bg-gradient-to-b from-[#293330] to-[#FEFFF4] bg-clip-text text-transparent text-[60px] font-inter font-normal leading-[60px] text-[#2D3B36]">
                    02
                  </p>
                </div>
                <div className="flex flex-col gap-[20px] w-[89%]">
                  <h3 className="text-[60px] font-inter font-normal leading-[60px] text-[#2D3B36]">
                    Everything Natural
                  </h3>
                  <p className="text-[18px] font-normal font-inter text-[#525349] w-[70%]">
                    Pure ingredients for pure skin. The perfect solution for
                    your skin care needs.
                  </p>
                </div>
              </div>
              <div className="flex gap-[20px]">
                <div className="w-[11%]">
                  <p className=" bg-gradient-to-b from-[#293330] to-[#FEFFF4] bg-clip-text text-transparent text-[60px] font-inter font-normal leading-[60px] text-[#2D3B36]">
                    03
                  </p>
                </div>
                <div className="flex flex-col gap-[20px] w-[89%]">
                  <h3 className="text-[60px] font-inter font-normal leading-[60px] text-[#2D3B36]">
                    All Handmade
                  </h3>
                  <p className="text-[18px] font-normal font-inter text-[#525349] w-[70%]">
                    Made with love and care. Just for you. Give your skin the
                    tender loving care it deserves.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="w-[50%] h-[120vh] relative">
            <img
              src="/images/section3.jpg"
              alt="skincare"
              className="rounded-[30px]"
            />
            <div className="absolute left-0 right-0 mx-auto bottom-[5%] w-[400px] h-[100px] flex items-center justify-between bg-[#FEF7E7] px-[9px] py-[15px] rounded-[100px]">
              <div className="w-[88px] h-[88px] rounded-full flex justify-center items-center border border-dotted border-[#2D3B36]">
                <div className="w-[80px] h-[80px] rounded-full object-cover bg-[#2D3B36] flex justify-center items-center">
                  <img
                    src="/images/award_light.svg"
                    alt="skincare"
                    className="w-[50px] h-[50px]"
                  />
                </div>
              </div>
              <div className="w-[65%]">
                <p className="font-inter font-normal text-[20px] leading-[25px] text-[#2D3B36] capitalize">
                  Best Skin Care Product Award Wining
                </p>
              </div>
            </div>
            <div className="flex justify-between pt-[20px] w-full text-[#2D3B36] text-[20px] font-inter">
              <p>SINCE 2001</p>
              <p>LEARN MORE</p>
            </div>
          </div>
        </div>
        <div className="w-[90%] mx-auto flex justify-between items-center pb-[5%]">
          <div className="w-fit flex items-center gap-[20px] bg-[#FEFFF4] rounded-[100px] px-[20px] py-[10px] border border-[#2D3B36]">
            <div className="w-[20px] h-[20px] rounded-full bg-[#2D3B36]"></div>
            <p className="font-inter font-normal text-[20px] leading-[25px] text-[#2D3B36] capitalize">
              Best Selling Products
            </p>
          </div>
          <div>
            <p className="font-inter font-normal text-[60px] leading-[60px] text-[#2D3B36] capitalize text-center">
              Skincare That Brings Out <br></br> Your Natural Radiance
            </p>
          </div>
          <div className="flex items-center gap-[50px]">
            <img
              src="/images/left_arrow.svg"
              alt="skincare"
              className="w-[80px] h-[80px]"
            />
            <img
              src="/images/right_arrow.svg"
              alt="skincare"
              className="w-[80px] h-[80px]"
            />
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-[30px] w-[90%] mx-auto">
          <img
            src="/images/section4_5.jpg"
            alt="skincare"
            className="w-full h-[600px] rounded-[20px]"
          />
          <img
            src="/images/section4_6.jpg"
            alt="skincare"
            className="w-full h-[600px] rounded-[20px]"
          />
          <img
            src="/images/section4_4.jpg"
            alt="skincare"
            className="w-full h-[600px] rounded-[20px]"
          />
        </div>
      </div>
    </>
  );
};

export default Home;
