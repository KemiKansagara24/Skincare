const Footer = () => {
  return (
    <footer className="text-center text-sm py-4 text-gray-600">
      {/* &copy; 2025 Skincare. All rights reserved. */}
    </footer>
  );
};

export default Footer;
