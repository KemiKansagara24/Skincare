const Header = () => {
  return (
    <div className=" bg-[#EFF5E1]">
      <div className="w-[90%] mx-auto pt-[50px] flex items-center justify-between">
        <div className="w-[13%]">
          <h1 className="w-[156px] text-[30px] leading-[22px] uppercase font-inter font-extrabold cursor-pointer text-[#2D3B36]">
            skincare
          </h1>
        </div>
        <div className="flex items-center justify-between w-[35%]">
          <p className="font-inter font-normal text-[20px] leading-[20px] capitalize cursor-pointer text-[#2D3B36]">
            all product
          </p>
          <p className="font-inter font-normal text-[20px] leading-[20px] capitalize cursor-pointer text-[#2D3B36]">
            serum
          </p>
          <p className="font-inter font-normal text-[20px] leading-[20px] capitalize cursor-pointer text-[#2D3B36]">
            sunscreen
          </p>
          <p className="font-inter font-normal text-[20px] leading-[20px] capitalize cursor-pointer text-[#2D3B36]">
            Bundle
          </p>
        </div>
        <div className="flex items-center gap-[20px]">
          <div className="flex items-center gap-[10px] cursor-pointer">
            <div className="w-[40px] h-[40px] bg-[#F8FEE5] rounded-full flex justify-center items-center">
              <img
                src="/images/cart.svg"
                alt="skincare"
                className="w-[20px] h-[20px]"
              />
            </div>
            <p className="font-inter font-normal text-[20px] leading-[20px] capitalize text-[#2D3B36]">
              cart (1)
            </p>
          </div>
          <div className="flex items-center gap-[10px]">
            <div className="w-[40px] h-[40px] bg-[#F8FEE5] rounded-full flex justify-center items-center cursor-pointer">
              <img
                src="/images/like.svg"
                alt="skincare"
                className="w-[20px] h-[20px]"
              />
            </div>
            <div className="w-[40px] h-[40px] bg-[#F8FEE5] rounded-full flex justify-center items-center cursor-pointer">
              <img
                src="/images/person.svg"
                alt="skincare"
                className="w-[20px] h-[20px]"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Header;
